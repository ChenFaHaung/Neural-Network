package Perceptron;

import java.util.ArrayList;

public class Run {
	static ArrayList<double[]> data = new ArrayList();
	public static void main(String[] args ){
		pic start = new pic();
	}
}


package Maltilayer;

import java.util.ArrayList;

import Perceptron.pic;

public class run {
	static ArrayList<double[]> data = new ArrayList();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GUI start = new GUI();
	}

}

package SOM;

public class run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GUI start = new GUI();
	}
}
